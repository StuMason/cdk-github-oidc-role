'''
# Welcome to your CDK TypeScript Construct Library project

You should explore the contents of this project. It demonstrates a CDK Construct Library that includes a construct (`GithubConstruct`)
which contains an Amazon SQS queue that is subscribed to an Amazon SNS topic.

The construct defines an interface (`GithubConstructProps`) to configure the visibility timeout of the queue.

## Useful commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
'''
import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

from ._jsii import *

import constructs


class GithubConstruct(
    constructs.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="github_construct.GithubConstruct",
):
    '''
    :stability: experimental
    '''

    def __init__(
        self,
        scope: constructs.Construct,
        id: builtins.str,
        *,
        github_organisation: builtins.str,
        github_repository: builtins.str,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param github_organisation: 
        :param github_repository: 

        :stability: experimental
        '''
        props = GithubConstructProps(
            github_organisation=github_organisation,
            github_repository=github_repository,
        )

        jsii.create(self.__class__, self, [scope, id, props])


@jsii.data_type(
    jsii_type="github_construct.GithubConstructProps",
    jsii_struct_bases=[],
    name_mapping={
        "github_organisation": "githubOrganisation",
        "github_repository": "githubRepository",
    },
)
class GithubConstructProps:
    def __init__(
        self,
        *,
        github_organisation: builtins.str,
        github_repository: builtins.str,
    ) -> None:
        '''
        :param github_organisation: 
        :param github_repository: 

        :stability: experimental
        '''
        self._values: typing.Dict[str, typing.Any] = {
            "github_organisation": github_organisation,
            "github_repository": github_repository,
        }

    @builtins.property
    def github_organisation(self) -> builtins.str:
        '''
        :stability: experimental
        '''
        result = self._values.get("github_organisation")
        assert result is not None, "Required property 'github_organisation' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def github_repository(self) -> builtins.str:
        '''
        :stability: experimental
        '''
        result = self._values.get("github_repository")
        assert result is not None, "Required property 'github_repository' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GithubConstructProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "GithubConstruct",
    "GithubConstructProps",
]

publication.publish()
